// NOTE: THIS FILE IS PUBLIC - NO SENSITIVE INFO HERE!
var config = {
  analytics: {
    google: ''
  }
};
